package com.oose2017.tlin44.hareandhounds;


/**
 * get the response data
 * @author Tianyi Lin
 *
 */
public class ResponseContent {
	private String reason;
	
	/**
	 * @param reason the response reason
	 */
	public ResponseContent(String reason) {
		this.reason = reason;
	}
}
